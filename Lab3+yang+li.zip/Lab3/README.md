
PicoSOC on TinyCOM
===============================================
[Picorv32](https://github.com/YosysHQ/picorv32/) RISC-V system-on-chip
implemented on TinyCOM Experimental Board.
The design is modified from iCEBreaker
[demonstration SOC](https://github.com/YosysHQ/picorv32/tree/master/picosoc)
in the PicoRV32 repository.

The application code runs directly from the SPI FLASH.
It can be updated separately from the FPGA code.

Files
-----

##### README.md
This file.

##### Makefile
Verilog and firmware compilation commands:
 - `make program-bitstream`: compile and upload the Verilog files.
 - `make program-firmware`: compile and upload the application code.
 - `make program-both`: compile and upload both.
Board will automatically boot into your image/firmware after flash.

Verilog compilation assumes that YosysHQ tools, including `yosys` and `nextpnr`, are available on path. Easiest way to provide these tools is to `source` the OSS CAD Suite `environment` file. 

For firmware compilation a RISC-V cross-compiler is needed. If you have a cross-compilation toolchain installed, you can modify `CC` and `OBJCOPY` to point at the appropriate executables. Otherwise, we recommend installing an LLVM-based toolchain, see the command below.

```bash
sudo apt install clang llvm make
```

You can verify the presence of the tools by running

```bash
make versions # Report the version info for each tool.
```

#### doc/

| File                           | Description                        |
|--------------------------------|------------------------------------|
| `README-picorv32.md`           | Original PicoRV32 documentation    |
| `README-picorsoc.md`           | Original PicoSOC documentation     |
| `TinyCOM.pdf`                  | TinyCom schematic                  |
| `TinyCOM_Experiment_Board.pdf` | TinyCOM experiment board schematic |


#### hw/
Verilog and FPGA configuration files

| File                | Description                            |
|---------------------|----------------------------------------|
| `tinycom_eb.v`      | Board specific modules and connections |
| `picosoc.v`         | PicoSOC system-on-chip                 |
| `picorv32.v`        | PicoRV32 RISC-V                        |
| `spimemio.v`        | SPI FLASH memory interface             |
| `ice40up5k_spram.v` | Wrapper module for ice40 RAM blocks    |
| `tinycom_eb.pcf`    | Pin configration file                  |


#### sw/
PicoRV32 firmware files

| File           | Description            |
|----------------|------------------------|
| `sections.lds` | Linker script          |
| `start.s`      | Start-up assembly code |
| `firmware.c`   | Application code       |

#include "minstd.h"
#define KIB 1024

#ifndef FLASH_FIRMWARE_ADDRESS
#define FLASH_FIRMWARE_ADDRESS 0x40000
#endif

extern void _heap_start;
extern uint32_t _mmio_flash_conf_serial;
extern uint8_t _mmio_flash_serial;

#define FIRMWARE_SIGNATURE (*((const uint64_t *)"TinyCOM3"))
struct firmware_descriptor {
    // This should be "TinyCOM3"
    uint64_t fw_signature;
    // The length of the firmware, in bytes.
    uint32_t fw_length;
    // The relative offset of the entrypoint
    uint32_t fw_entry;
};

extern void flashio(uint8_t *data, int len, uint8_t wrencmd);
void set_flash_qspi_flag()
{
        const uint32_t addr_cr1v = 0x800002;
        // Read Status Register-2 (35h)
        uint8_t buffer[8] = { 0x35, 0xFF };

        flashio(buffer, 2, 0);
        uint8_t sr2 = buffer[1];

        // Write Enable for Volatile Status Register (50h)
        // Write Status Register-2 (31h)
        buffer[0] = 0x31;
        buffer[1] = sr2 | 0x02; // Set QE
        flashio(buffer, 5, 0x50);

        _mmio_flash_conf_serial = (_mmio_flash_conf_serial & ~0x007F0000) | 0x00240000;
}

void isr_handler(void) {
    puts("SEGFAULT!");
    while(1);
}

int main(void) {
    puts("start-up");
    set_flash_qspi_flag();

    struct firmware_descriptor fd;

    puts("loading firmware to memory...");
    memcpy(&fd, &_mmio_flash_serial+FLASH_FIRMWARE_ADDRESS, sizeof(fd));

    if (fd.fw_signature != FIRMWARE_SIGNATURE)
    {
        puts("Invalid firmware signature! Got:");
        print_hex((uint8_t *) &fd.fw_signature, sizeof(fd.fw_signature));

        puts("Halting!");
        while (1);
    }
    else if (fd.fw_length > 20 * KIB)
    {
        puts("FIRMWARE TOO LARGE! Got:");
        char cbuff[5];
        memcpy(&cbuff, (uint8_t *) (&fd.fw_length), 4);
        cbuff[4] = '\0';
        puts(cbuff);

        puts("Halting!");
        while (1);
    }

    memcpy(&_heap_start, &fd, sizeof(fd));
    memcpy((uint8_t*) &_heap_start + sizeof(fd), &_mmio_flash_serial+FLASH_FIRMWARE_ADDRESS+sizeof(fd), fd.fw_length);

    puts("running _start...");
    int (*entrypoint)(void) = (void*)((uint8_t *) &_heap_start + fd.fw_entry);
    return entrypoint();
}

#ifndef SPI_H
#define SPI_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

struct spi_peripheral {
    volatile union spi_csr {
        uint32_t bits;
        struct {
            uint8_t
                rx_full: 1,
                rx_empty: 1,
                tx_full: 1,
                tx_empty: 1,
                :0, // Pad to next byte
                start: 1,
                clkpol: 1,
                idle: 1,
                __padding: 4,
                clear: 1
                ;
            uint8_t clkdiv;
        };
    } control;
    /* TX FIFO write location */
    volatile uint8_t transmit_data;
    uint8_t __reserved_1[3]; // Padding needed
    /* RX FIFO read location */
    volatile uint8_t receive_data;
    uint8_t __reserved_2[3];
};

void spi_reset(volatile struct spi_peripheral *spi);
void spi_configure(volatile struct spi_peripheral *spi, bool cpol, int clkdiv);
void spi_begin(volatile struct spi_peripheral *spi);
void spi_transfer(volatile struct spi_peripheral *spi, size_t nb, uint8_t *data);
void spi_end(volatile struct spi_peripheral *spi);

#endif
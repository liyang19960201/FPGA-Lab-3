#include "spi.h"

void spi_reset(volatile struct spi_peripheral *spi)
{
    // Clear the internal state.
    spi->control.clear = 1;
    // spi->control.clear = 0; // Current hardware implementation clears all registers on clear

    spi->control.start = 0;
    spi->control.clkpol = 0;
    spi->control.clkdiv = 0;
}

void spi_configure(volatile struct spi_peripheral *spi, bool cpol, int clkdiv)
{
    spi->control.clkdiv = clkdiv;
    spi->control.clkpol = cpol;
}

void spi_begin(volatile struct spi_peripheral *spi)
{
    spi->control.start = 1;
}

void spi_transfer(volatile struct spi_peripheral *spi, size_t nb, uint8_t *data) 
{
    uint8_t
        *rptr = data,
        *wptr = data, 
        *const end = data + nb;

    while (wptr < end) {
        while (rptr < end && !spi->control.tx_full) {
            spi->transmit_data = *rptr;
            rptr += 1;
        }
        
        *wptr = spi->receive_data;
        wptr += 1;
    }
}

void spi_end(volatile struct spi_peripheral *spi)
{
    spi->control.start = 0;
}
// SPDX-FileCopyrightText: 2024 Kalle Koskinen <kalle.koskinen@aalto.fi>, Veli-Matti Rantanen <veli-matti.rantanen@aalto.fi>
//
// SPDX-License-Identifier: ISC

#include <stdint.h>
#include <stdbool.h>

#include "minstd.h"

typedef unsigned long clock_t;
#define CLOCKS_PER_SECOND ((clock_t) 12000000ul)
inline volatile clock_t clock(void) {
    clock_t clocks;
    asm volatile ("rdtime %0" : "=r" (clocks));
    return clocks;
}

void millisleep(unsigned millis) {
    for (unsigned i = 0; i < millis; i++){
        clock_t end = clock() + (CLOCKS_PER_SECOND / 1000);
        while (clock() < end);
    }
}

struct gpio_control {
    uint32_t data;
    uint32_t output_enable;
};

struct  pwm_peripheral
{
    uint32_t member;
};

   

extern volatile struct gpio_control _mmio_gpio;
extern volatile struct spi_peripheral _mmio_spi;
extern volatile struct pwm_peripheral _mmio_pwm;

volatile struct gpio_control *const gpio = &_mmio_gpio;
volatile struct spi_peripheral *const spi = &_mmio_spi;
volatile struct pwm_peripheral *const pwm = &_mmio_pwm;

int main()
{
    puts("My code is running :)");

    // Reset all outputs
    gpio->data = 0;
    gpio->output_enable = 0;

    // Turn off LED2...
    gpio->data |= (0x1 << 9);

    // ... and enable the GPIO output at the position of LED2.
    gpio->output_enable |= (0x1 << 9);
    gpio->output_enable |= (0x1 << 10);
    gpio->output_enable |= (0x1 << 1);

    // Loop forever
    while (1) {
        // Toggle the LED2 every 500 ms.
     
        gpio->data ^= (0x1 << 9);
    
        millisleep(250);
        
        if (~gpio->data & (0x1 << 14) ) {
            gpio->data &= ~(0x1 << 10);
            
            puts("Button Pressed)");
        }
        else {
            puts("Button not Pressed)");
            gpio->data |= (0x1 << 10);
        }


        pwm->member = (0x10);


    }
}


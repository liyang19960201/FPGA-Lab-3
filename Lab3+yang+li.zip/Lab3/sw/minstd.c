#include "minstd.h"

#ifndef MMIO_USB_ADDRESS
#   define MMIO_USB_ADDRESS 0x45100000
#endif

void *  memcpy(void *dst, const void *src, size_t nb)
{
    uint8_t *dptr = dst;
    const uint8_t *sptr = src;
    while (nb --> 0)
    {
        *dptr = *sptr;
        dptr++;
        sptr++;
    }

    return dst;
}

void *memset(void *dst, int value, size_t nb)
{
    for (uint8_t *ptr = dst, *const end = ptr + nb; ptr < end; ptr++)
        *ptr = value;
    
    return dst;
}

int memcmp(const void *a, const void *b, size_t nb)
{
    const uint8_t *A = a, *B = b;
    unsigned offset = 0;
    
    while (offset < nb && A[offset] == B[offset]) {
        offset++;
    }

    if (offset == nb)
        return 0;
    
    return A[offset] - B[offset];
}

struct serial {
    volatile union serial_csr {
        uint32_t bits;
        struct {
            uint8_t
                rx_full: 1,
                rx_empty: 1,
                tx_full: 1,
                tx_empty: 1,
                :0 // Pad to next byte
                ;
        };
    } control;
    /* TX FIFO write location */
    volatile uint8_t transmit_data;
    uint8_t __reserved_1[3]; // Padding needed
    /* RX FIFO read location */
    volatile uint8_t receive_data;
    uint8_t __reserved_2[3];
};

extern volatile struct serial _mmio_usb_serial;
volatile struct serial *const mmio_usb = &_mmio_usb_serial;

int putchar(int c) {
    mmio_usb->transmit_data = c;
    return 0;
}

int puts(const char *s) {
    const char *it = s;
    for (int c=*it; c; c = *(++it)) {
        putchar(c);
    }
    putchar('\n');
    putchar('\r');
    return 0;
}

int gets(char *s) {
    while(1) {
        int c = getchar();
        *s++ = c;
        if (c == '\n') {
            *s = 0;
            return 0;
        } else if (c == -1) {
            return -1;
        }
    }
}

int getchar(void) {
    return mmio_usb->receive_data;
}
#ifndef MINSTD_H
#define MINSTD_H

#include <stdint.h>
#include <stddef.h>

void *  memcpy(void *dst, const void *src, size_t nb);
void *  memset(void *dst, int value, size_t nb);
int     memcmp(const void *a, const void *b, size_t nb);

int     puts(const char *);
int     putchar(int);

int     gets(char *);
int     getchar(void);

#endif
